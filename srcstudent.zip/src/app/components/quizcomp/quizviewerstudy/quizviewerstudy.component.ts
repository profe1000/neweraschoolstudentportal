import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quizviewerstudy',
  templateUrl: './quizviewerstudy.component.html',
  styleUrls: ['./quizviewerstudy.component.scss'],
})
export class QuizviewerstudyComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}

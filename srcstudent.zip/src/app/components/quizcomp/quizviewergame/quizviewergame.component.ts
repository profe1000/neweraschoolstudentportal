import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quizviewergame',
  templateUrl: './quizviewergame.component.html',
  styleUrls: ['./quizviewergame.component.scss'],
})
export class QuizviewergameComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}

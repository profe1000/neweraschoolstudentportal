import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quizviewerexam',
  templateUrl: './quizviewerexam.component.html',
  styleUrls: ['./quizviewerexam.component.scss'],
})
export class QuizviewerexamComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}

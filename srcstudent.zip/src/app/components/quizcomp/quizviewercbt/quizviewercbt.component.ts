import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quizviewercbt',
  templateUrl: './quizviewercbt.component.html',
  styleUrls: ['./quizviewercbt.component.scss'],
})
export class QuizviewercbtComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}

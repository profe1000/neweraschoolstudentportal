import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-noteviewer',
  templateUrl: './noteviewer.component.html',
  styleUrls: ['./noteviewer.component.scss'],
})
export class NoteviewerComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}

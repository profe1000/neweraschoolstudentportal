import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-downloadviewer',
  templateUrl: './downloadviewer.component.html',
  styleUrls: ['./downloadviewer.component.scss'],
})
export class DownloadviewerComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-downloadlist',
  templateUrl: './downloadlist.component.html',
  styleUrls: ['./downloadlist.component.scss'],
})
export class DownloadlistComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}

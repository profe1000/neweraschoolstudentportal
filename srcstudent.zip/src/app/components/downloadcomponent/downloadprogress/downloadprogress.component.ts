import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-downloadprogress',
  templateUrl: './downloadprogress.component.html',
  styleUrls: ['./downloadprogress.component.scss'],
})
export class DownloadprogressComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-downloadfile',
  templateUrl: './downloadfile.component.html',
  styleUrls: ['./downloadfile.component.scss'],
})
export class DownloadfileComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}

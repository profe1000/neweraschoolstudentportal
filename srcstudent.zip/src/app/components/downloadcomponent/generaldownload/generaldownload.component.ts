import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-generaldownload',
  templateUrl: './generaldownload.component.html',
  styleUrls: ['./generaldownload.component.scss'],
})
export class GeneraldownloadComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}

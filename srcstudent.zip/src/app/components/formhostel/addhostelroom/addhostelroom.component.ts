import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addhostelroom',
  templateUrl: './addhostelroom.component.html',
  styleUrls: ['./addhostelroom.component.scss'],
})
export class AddhostelroomComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addhostelcategory',
  templateUrl: './addhostelcategory.component.html',
  styleUrls: ['./addhostelcategory.component.scss'],
})
export class AddhostelcategoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}

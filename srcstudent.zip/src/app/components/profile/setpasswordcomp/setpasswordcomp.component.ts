import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-setpasswordcomp',
  templateUrl: './setpasswordcomp.component.html',
  styleUrls: ['./setpasswordcomp.component.scss'],
})
export class SetpasswordcompComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}

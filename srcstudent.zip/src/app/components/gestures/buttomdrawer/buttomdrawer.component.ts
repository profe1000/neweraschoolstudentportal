import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buttomdrawer',
  templateUrl: './buttomdrawer.component.html',
  styleUrls: ['./buttomdrawer.component.scss'],
})
export class ButtomdrawerComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-transportpayment',
  templateUrl: './transportpayment.component.html',
  styleUrls: ['./transportpayment.component.scss'],
})
export class TransportpaymentComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}

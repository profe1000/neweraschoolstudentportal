import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sessionnresult',
  templateUrl: './sessionnresult.component.html',
  styleUrls: ['./sessionnresult.component.scss'],
})
export class SessionnresultComponent implements OnInit {




  constructor() { }

  ngOnInit() {}

}

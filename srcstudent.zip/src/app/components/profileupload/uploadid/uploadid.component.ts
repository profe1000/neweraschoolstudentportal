import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-uploadid',
  templateUrl: './uploadid.component.html',
  styleUrls: ['./uploadid.component.scss'],
})
export class UploadidComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
